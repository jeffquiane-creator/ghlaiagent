@echo off
echo ========================================
echo 🚀 Starting GoHighLevel AI Agent
echo ========================================
echo.

REM Check if ANTHROPIC_API_KEY is set
if "%ANTHROPIC_API_KEY%"=="" (
    echo ⚠️  WARNING: ANTHROPIC_API_KEY not set!
    echo Please set it with: set ANTHROPIC_API_KEY=your-key-here
    echo.
)

REM Check if virtual environment exists
if not exist "venv" (
    echo 📦 Creating virtual environment...
    python -m venv venv
)

echo 🔧 Activating virtual environment...
call venv\Scripts\activate.bat

echo 📥 Installing dependencies...
pip install -q -r requirements.txt

echo.
echo ✅ Starting web server...
echo 📱 Access the app at: http://localhost:5000
echo.
echo Press Ctrl+C to stop the server
echo.

python app.py
