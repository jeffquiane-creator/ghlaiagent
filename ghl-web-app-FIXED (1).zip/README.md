# GoHighLevel AI Agent - Web App 🚀

A beautiful, mobile-friendly web interface to control your GoHighLevel CRM with AI!

## Features ✨

- 💬 **Chat Interface** - Natural conversation with AI agent
- 📱 **Mobile-First** - Works perfectly on phones, tablets, and desktop
- 🎨 **Modern Design** - Sleek dark theme with smooth animations
- ⚡ **Real-time** - Instant responses and updates
- 🔒 **Secure** - Your GHL credentials stay safe

## Quick Start (5 minutes)

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Set Environment Variables

**On Mac/Linux:**
```bash
export ANTHROPIC_API_KEY="your-anthropic-api-key"
export GHL_API_KEY="pit-08e43a3b-311c-4eca-85ed-5aa15cf9c9ed"
export GHL_LOCATION_ID="oRAdNjgqsxfmfcoNLmAG"
```

**On Windows (PowerShell):**
```powershell
$env:ANTHROPIC_API_KEY="your-anthropic-api-key"
$env:GHL_API_KEY="pit-08e43a3b-311c-4eca-85ed-5aa15cf9c9ed"
$env:GHL_LOCATION_ID="oRAdNjgqsxfmfcoNLmAG"
```

**Or create a `.env` file:**
```
ANTHROPIC_API_KEY=your-anthropic-api-key-here
GHL_API_KEY=pit-08e43a3b-311c-4eca-85ed-5aa15cf9c9ed
GHL_LOCATION_ID=oRAdNjgqsxfmfcoNLmAG
```

### 3. Run the App

```bash
python app.py
```

### 4. Open in Browser

Go to: **http://localhost:5000**

Access from your phone by using your computer's IP address:
- Find your IP: `ipconfig` (Windows) or `ifconfig` (Mac/Linux)
- Open: `http://YOUR-IP:5000` on your phone

## What You Can Do 🎯

### Create Contacts
```
Add contact John Doe, email john@example.com, phone 555-1234, tag him as Hot Lead
```

### Search Contacts
```
Search for Mike
Find contacts with email @gmail.com
```

### Add Notes
```
Add note to John Doe: Very interested in downtown properties
```

### Add Tags
```
Tag Sarah Johnson as VIP Client
Add tags Hot Lead and Q1-2025 to john@example.com
```

### And More!
- Schedule appointments
- Move opportunities through pipeline
- Update contact information
- Bulk operations (coming soon)

## Mobile Access 📱

### Option 1: Local Network (Same WiFi)
1. Find your computer's IP address
2. On your phone, go to `http://YOUR-IP:5000`
3. Bookmark it for easy access!

### Option 2: Deploy Online (Recommended for Team)
Deploy to the cloud so your team can access from anywhere:

**Deploy to Heroku (Free):**
```bash
# Install Heroku CLI
# Then:
heroku create your-ghl-agent
git init
git add .
git commit -m "Initial commit"
git push heroku main
heroku config:set ANTHROPIC_API_KEY=your-key
heroku config:set GHL_API_KEY=pit-08e43a3b-311c-4eca-85ed-5aa15cf9c9ed
heroku config:set GHL_LOCATION_ID=oRAdNjgqsxfmfcoNLmAG
```

**Deploy to Replit (Easiest):**
1. Go to replit.com
2. Create new Repl → Import from GitHub
3. Add your environment variables in Secrets
4. Click Run!
5. Share the URL with your team

**Deploy to Railway (Fast):**
```bash
# Install Railway CLI
railway init
railway up
railway variables set ANTHROPIC_API_KEY=your-key
railway variables set GHL_API_KEY=pit-08e43a3b-311c-4eca-85ed-5aa15cf9c9ed
railway variables set GHL_LOCATION_ID=oRAdNjgqsxfmfcoNLmAG
```

## Production Deployment 🚀

For production use with your team:

### Using Gunicorn (Recommended)
```bash
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Using Docker
```bash
docker build -t ghl-ai-agent .
docker run -p 5000:5000 \
  -e ANTHROPIC_API_KEY=your-key \
  -e GHL_API_KEY=pit-08e43a3b-311c-4eca-85ed-5aa15cf9c9ed \
  -e GHL_LOCATION_ID=oRAdNjgqsxfmfcoNLmAG \
  ghl-ai-agent
```

## Architecture 🏗️

```
┌─────────────┐
│   Browser   │  ← Beautiful chat interface
└──────┬──────┘
       │
       ├─ HTML/CSS/JS (Frontend)
       │
┌──────▼──────┐
│ Flask Server│  ← Python backend
└──────┬──────┘
       │
       ├─ Anthropic API (Claude AI)
       │
       └─ GoHighLevel API
```

## Customization 🎨

### Change the Theme
Edit `static/css/style.css` and modify the `:root` variables:

```css
:root {
    --primary-color: #6366f1;  /* Change to your brand color */
    --bg-color: #0f172a;       /* Background color */
    /* ... */
}
```

### Add Custom Commands
Edit `app.py` and add new action handlers in the `execute_command` method.

### Customize Suggestions
Edit `templates/index.html` and modify the suggestion buttons in the welcome message.

## Troubleshooting 🔧

### "ANTHROPIC_API_KEY not set"
Make sure you've exported the environment variable or created a `.env` file.

### Can't access from phone
- Make sure your phone and computer are on the same WiFi
- Check your firewall isn't blocking port 5000
- Try using your computer's IP address instead of `localhost`

### "Connection Error" in status
- Verify your GHL API key is valid
- Check your Location ID is correct
- Make sure GoHighLevel API is accessible

### Commands not working
- Check the browser console (F12) for errors
- Verify your Anthropic API key has credits
- Test the connection using the status indicator

## Next Steps 🎯

Ready to enhance your AI agent? Here's what we can add:

1. **Voice Commands** - Speak your commands instead of typing
2. **Workflow Builder** - Create automations through chat
3. **Bulk Operations** - Update hundreds of contacts at once
4. **Analytics Dashboard** - See usage stats and insights
5. **Team Management** - Multiple users with permissions
6. **Slack/Teams Integration** - Control GHL from chat apps
7. **SMS/WhatsApp Commands** - Text your AI agent

## Security Notes 🔒

- Never commit your `.env` file or API keys to git
- Use environment variables for all sensitive data
- Consider adding authentication for team deployment
- Use HTTPS in production (automatic with Heroku/Railway)

## Support 💬

Having issues? Want to add features?
- Check the browser console for errors
- Review the Flask server logs
- Test your API keys with the connection tester

## What Your Team Will Say 😍

> "This is incredible! I just told it to add a contact and it did it!"

> "I can do this from my phone while driving between showings!"

> "No more logging into GHL for simple tasks!"

> "The AI actually understands what I want!"

**Enjoy your new AI-powered CRM assistant! 🎉**
