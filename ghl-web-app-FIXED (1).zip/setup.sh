#!/bin/bash

# GHL AI Agent - Automated Setup Script
# This script helps you deploy to various platforms

echo "╔════════════════════════════════════════╗"
echo "║   GoHighLevel AI Agent Setup Wizard    ║"
echo "╔════════════════════════════════════════╗"
echo ""

PS3='Choose your deployment platform: '
options=("Replit (Easiest)" "Render (Free)" "Railway" "Heroku" "Local Development" "Quit")
select opt in "${options[@]}"
do
    case $opt in
        "Replit (Easiest)")
            echo ""
            echo "🚀 Deploying to Replit..."
            echo ""
            echo "📋 Follow these steps:"
            echo ""
            echo "1. Go to: https://replit.com"
            echo "2. Sign up (free)"
            echo "3. Click '+ Create Repl'"
            echo "4. Choose 'Import from GitHub'"
            echo "5. Paste: YOUR_GITHUB_URL_HERE"
            echo "6. Add these Secrets:"
            echo "   - ANTHROPIC_API_KEY: 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"
            echo "   - GHL_API_KEY: pit-08e43a3b-311c-4eca-85ed-5aa15cf9c9ed"
            echo "   - GHL_LOCATION_ID: oRAdNjgqsxfmfcoNLmAG"
            echo "7. Click 'Run'!"
            echo ""
            break
            ;;
        "Render (Free)")
            echo ""
            echo "🌐 Deploying to Render..."
            echo ""
            echo "📋 Follow these steps:"
            echo ""
            echo "1. Go to: https://render.com"
            echo "2. Sign up (free)"
            echo "3. Click 'New +' → 'Web Service'"
            echo "4. Connect your GitHub repo (or upload files)"
            echo "5. Add these Environment Variables:"
            echo "   - ANTHROPIC_API_KEY: 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"
            echo "   - GHL_API_KEY: pit-08e43a3b-311c-4eca-85ed-5aa15cf9c9ed"
            echo "   - GHL_LOCATION_ID: oRAdNjgqsxfmfcoNLmAG"
            echo "6. Click 'Create Web Service'"
            echo ""
            break
            ;;
        "Railway")
            echo ""
            echo "🚂 Deploying to Railway..."
            echo ""
            echo "Installing Railway CLI..."
            npm i -g @railway/cli
            echo ""
            echo "Initializing project..."
            railway init
            echo ""
            echo "Setting environment variables..."
            railway variables set ANTHROPIC_API_KEY=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
            railway variables set GHL_API_KEY=pit-08e43a3b-311c-4eca-85ed-5aa15cf9c9ed
            railway variables set GHL_LOCATION_ID=oRAdNjgqsxfmfcoNLmAG
            echo ""
            echo "Deploying..."
            railway up
            echo ""
            echo "✅ Done! Your app is live!"
            break
            ;;
        "Heroku")
            echo ""
            echo "☁️  Deploying to Heroku..."
            echo ""
            echo "Creating Heroku app..."
            heroku create ghl-ai-agent-$RANDOM
            echo ""
            echo "Setting config vars..."
            heroku config:set ANTHROPIC_API_KEY=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
            heroku config:set GHL_API_KEY=pit-08e43a3b-311c-4eca-85ed-5aa15cf9c9ed
            heroku config:set GHL_LOCATION_ID=oRAdNjgqsxfmfcoNLmAG
            echo ""
            echo "Deploying..."
            git push heroku main
            echo ""
            echo "✅ Done! Opening your app..."
            heroku open
            break
            ;;
        "Local Development")
            echo ""
            echo "💻 Setting up local development..."
            echo ""
            echo "Installing dependencies..."
            pip install -r requirements.txt
            echo ""
            echo "Setting environment variables..."
            export ANTHROPIC_API_KEY="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"
            export GHL_API_KEY="pit-08e43a3b-311c-4eca-85ed-5aa15cf9c9ed"
            export GHL_LOCATION_ID="oRAdNjgqsxfmfcoNLmAG"
            echo ""
            echo "✅ Setup complete!"
            echo ""
            echo "Starting server..."
            python app.py
            break
            ;;
        "Quit")
            break
            ;;
        *) echo "Invalid option $REPLY";;
    esac
done

echo ""
echo "🎉 Setup complete!"
echo ""
