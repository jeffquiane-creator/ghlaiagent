# 🤖 GoHighLevel AI Agent

Control your GoHighLevel CRM with natural language commands!

[![Run on Replit](https://replit.com/badge/github/yourusername/ghl-ai-agent)](https://replit.com/new/github/yourusername/ghl-ai-agent)

## ⚡ One-Click Deploy

### Deploy to Replit (Recommended - Easiest!)

1. Click this button: [![Run on Replit](https://replit.com/badge)](https://replit.com/@replit/Flask)
2. Fork the repl
3. Add your API keys in Secrets (see below)
4. Click Run!

### Deploy to Render

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy)

### Deploy to Railway

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/template)

---

## 🔑 Required Environment Variables

After deploying, add these three secrets/environment variables:

```
ANTHROPIC_API_KEY=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

GHL_API_KEY=pit-08e43a3b-311c-4eca-85ed-5aa15cf9c9ed

GHL_LOCATION_ID=oRAdNjgqsxfmfcoNLmAG
```

---

## 🚀 Features

- 💬 **Natural Language Commands** - Just tell it what you want
- 📱 **Mobile-First Design** - Works perfectly on phones
- ⚡ **Real-time Updates** - Instant feedback
- 🎨 **Beautiful Interface** - Modern dark theme
- 🔒 **Secure** - Your data stays private

---

## 📝 Example Commands

```
Add contact John Doe, email john@example.com, tag as Hot Lead

Search for contacts named Mike

Add note to John Doe: Very interested in properties

Tag sarah@example.com as VIP Client

Schedule appointment with Jane tomorrow at 2pm
```

---

## 🛠️ Local Development

If you want to run it locally:

```bash
# Clone the repo
git clone https://github.com/yourusername/ghl-ai-agent.git
cd ghl-ai-agent

# Install dependencies
pip install -r requirements.txt

# Set environment variables
export ANTHROPIC_API_KEY="your-key"
export GHL_API_KEY="your-key"
export GHL_LOCATION_ID="your-id"

# Run the app
python app.py
```

Then open http://localhost:5000

---

## 📱 Mobile Access

Once deployed, you can:
- Access from any device via the URL
- Add to phone home screen for app-like experience
- Share with unlimited team members
- Works offline after initial load

---

## 🎯 Tech Stack

- **Backend**: Python Flask
- **AI**: Anthropic Claude API
- **CRM**: GoHighLevel API
- **Frontend**: Vanilla JavaScript (no frameworks!)
- **Deployment**: Works on Replit, Render, Railway, Heroku

---

## 📄 License

MIT License - Feel free to use and modify!

---

## 🆘 Support

Having issues? Check out:
- [Deployment Guide](DEPLOY-TO-REPLIT.md)
- [Troubleshooting](FIX-FAILED-TO-FETCH.md)

---

**Built with ❤️ for real estate agents who want to work smarter, not harder!**
